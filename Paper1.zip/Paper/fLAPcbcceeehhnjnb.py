Regina 7.3
Software for low-dimensional topology
Copyright (c) 1999-2023, The Regina development team

The (invisible) root of the packet tree is in the variable [root].
The selected packet (fLAPcbcceeehhnjnb) is in the variable [item].
Ready.
>>> item.vertex(0).builtLinkInclusion()
Traceback (most recent call last):
  File "<console>", line 1, in <module>
AttributeError: 'regina.engine.Face3_0' object has no attribute 'builtLinkInclusion'. Did you mean: 'buildLinkInclusion'?
>>> item.vertex(0).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (2310), 2 -> 1 (0231), 3 -> 2 (0231), 4 -> 0 (0231), 5 -> 4 (2310), 6 -> 3 (0231), 7 -> 1 (1023), 8 -> 4 (2301), 9 -> 1 (1230), 10 -> 3 (0123), 11 -> 3 (1230), 12 -> 4 (0132), 13 -> 0 (0123), 14 -> 2 (1032), 15 -> 2 (0123), 16 -> 1 (0132), 17 -> 0 (0132)>
>>> 
>>> item.vertex(1).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 3 (0132), 1 -> 4 (0123)>

