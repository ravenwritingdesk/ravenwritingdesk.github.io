Regina 7.3
Software for low-dimensional topology
Copyright (c) 1999-2023, The Regina development team

The (invisible) root of the packet tree is in the variable [root].
The selected packet (fLAPcbcceeemejrvj) is in the variable [item].
Ready.
>>> item.vertex(0).buildLink()
<regina.Triangulation2: Closed orientable 2-D triangulation, f = ( 9 27 18 )>
>>> item.vertex(0).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (1230), 2 -> 1 (0132), 3 -> 1 (0123), 4 -> 0 (0132), 5 -> 3 (0132), 6 -> 0 (0123), 7 -> 2 (0312), 8 -> 2 (0231), 9 -> 4 (3201), 10 -> 4 (3102), 11 -> 2 (1203), 12 -> 1 (2031), 13 -> 1 (1230), 14 -> 3 (1230), 15 -> 3 (0231), 16 -> 4 (1203), 17 -> 0 (0231)>
>>> item.vertex(1).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 3 (0123), 1 -> 4 (1230)>

