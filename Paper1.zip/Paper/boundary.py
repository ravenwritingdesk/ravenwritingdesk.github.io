Regina 7.3
Software for low-dimensional topology
Copyright (c) 1999-2023, The Regina development team

The (invisible) root of the packet tree is in the variable [root].
The selected packet (Whitehead link (Complement)) is in the variable [item].
Ready.
>>> item
<regina.PacketOfSnapPeaTriangulation: Ideal orientable 3-D triangulation, f = ( 2 5 10 5 ), cusps: [ vertex 0, vertex 1 ]>
>>> item.vertex(0).buildLink
<bound method PyCapsule.buildLink of <regina.Face3_0: Vertex 0, torus cusp, degree 18: 0 (0), 2 (0), 1 (0), 4 (2), 2 (3), 4 (0), 3 (0), 3 (1), 2 (2), 3 (3), 0 (2), 2 (1), 0 (1), 1 (1), 4 (1), 1 (2), 0 (3), 4 (3)>>
>>> item.vertex(1).buildLink()
<regina.Triangulation2: Closed orientable 2-D triangulation, f = ( 1 3 2 )>
>>> item.vertex(0).buildLink()
<regina.Triangulation2: Closed orientable 2-D triangulation, f = ( 9 27 18 )>
>>> item.vertex(0).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (3210), 2 -> 1 (1230), 3 -> 4 (0312), 4 -> 2 (0123), 5 -> 4 (2310), 6 -> 3 (1320), 7 -> 3 (0321), 8 -> 2 (0132), 9 -> 3 (0123), 10 -> 0 (0132), 11 -> 2 (0321), 12 -> 0 (0231), 13 -> 1 (0231), 14 -> 4 (0321), 15 -> 1 (0132), 16 -> 0 (0123), 17 -> 4 (0123)>
>>> item.vertex(1).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 1 (0123), 1 -> 3 (0132)>
>>> item.vertex(0).buildLinkInclusion().facePerm()
Traceback (most recent call last):
  File "<console>", line 1, in <module>
TypeError: facePerm(): incompatible function arguments. The following argument types are supported:
    1. (self: regina.Isomorphism3, arg0: int) -> regina.Perm4

Invoked with: <regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (3210), 2 -> 1 (1230), 3 -> 4 (0312), 4 -> 2 (0123), 5 -> 4 (2310), 6 -> 3 (1320), 7 -> 3 (0321), 8 -> 2 (0132), 9 -> 3 (0123), 10 -> 0 (0132), 11 -> 2 (0321), 12 -> 0 (0231), 13 -> 1 (0231), 14 -> 4 (0321), 15 -> 1 (0132), 16 -> 0 (0123), 17 -> 4 (0123)>
>>> item.vertex(0).buildLinkInclusion().facePerm
<bound method PyCapsule.facePerm of <regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (3210), 2 -> 1 (1230), 3 -> 4 (0312), 4 -> 2 (0123), 5 -> 4 (2310), 6 -> 3 (1320), 7 -> 3 (0321), 8 -> 2 (0132), 9 -> 3 (0123), 10 -> 0 (0132), 11 -> 2 (0321), 12 -> 0 (0231), 13 -> 1 (0231), 14 -> 4 (0321), 15 -> 1 (0132), 16 -> 0 (0123), 17 -> 4 (0123)>>
>>> item.vertex(1).buildLinkInclusion().facePerm
<bound method PyCapsule.facePerm of <regina.Isomorphism3: 0 -> 1 (0123), 1 -> 3 (0132)>>
>>> item.vertex(1).buildLinkInclusion().tetImage
<bound method PyCapsule.tetImage of <regina.Isomorphism3: 0 -> 1 (0123), 1 -> 3 (0132)>>
>>> item.vertex(0).buildLinkInclusion().tetImage
<bound method PyCapsule.tetImage of <regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (3210), 2 -> 1 (1230), 3 -> 4 (0312), 4 -> 2 (0123), 5 -> 4 (2310), 6 -> 3 (1320), 7 -> 3 (0321), 8 -> 2 (0132), 9 -> 3 (0123), 10 -> 0 (0132), 11 -> 2 (0321), 12 -> 0 (0231), 13 -> 1 (0231), 14 -> 4 (0321), 15 -> 1 (0132), 16 -> 0 (0123), 17 -> 4 (0123)>>


The (invisible) root of the packet tree is in the variable [root].
The selected packet (fLAPcbcceeehhnjnb) is in the variable [item].
Ready.
>>> item.vertex(0).builtLinkInclusion()
Traceback (most recent call last):
  File "<console>", line 1, in <module>
AttributeError: 'regina.engine.Face3_0' object has no attribute 'builtLinkInclusion'. Did you mean: 'buildLinkInclusion'?
>>> item.vertex(0).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (2310), 2 -> 1 (0231), 3 -> 2 (0231), 4 -> 0 (0231), 5 -> 4 (2310), 6 -> 3 (0231), 7 -> 1 (1023), 8 -> 4 (2301), 9 -> 1 (1230), 10 -> 3 (0123), 11 -> 3 (1230), 12 -> 4 (0132), 13 -> 0 (0123), 14 -> 2 (1032), 15 -> 2 (0123), 16 -> 1 (0132), 17 -> 0 (0132)>
>>> 
>>> item.vertex(1).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 3 (0132), 1 -> 4 (0123)>


The (invisible) root of the packet tree is in the variable [root].
The selected packet (fLAPcbcceeemejrvj) is in the variable [item].
Ready.
>>> item.vertex(0).buildLink()
<regina.Triangulation2: Closed orientable 2-D triangulation, f = ( 9 27 18 )>
>>> item.vertex(0).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (1230), 2 -> 1 (0132), 3 -> 1 (0123), 4 -> 0 (0132), 5 -> 3 (0132), 6 -> 0 (0123), 7 -> 2 (0312), 8 -> 2 (0231), 9 -> 4 (3201), 10 -> 4 (3102), 11 -> 2 (1203), 12 -> 1 (2031), 13 -> 1 (1230), 14 -> 3 (1230), 15 -> 3 (0231), 16 -> 4 (1203), 17 -> 0 (0231)>
>>> item.vertex(1).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 3 (0123), 1 -> 4 (1230)>

The (invisible) root of the packet tree is in the variable [root].
The selected packet (fLLQcbcceeetondqt) is in the variable [item].
Ready.
>>> item.vertex(0).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (1320), 2 -> 1 (0123), 3 -> 3 (1230), 4 -> 2 (0231), 5 -> 1 (3012), 6 -> 0 (0123), 7 -> 4 (2013), 8 -> 4 (3012), 9 -> 2 (2103), 10 -> 1 (0231), 11 -> 0 (0132), 12 -> 3 (0132), 13 -> 3 (0231), 14 -> 2 (0132), 15 -> 0 (0231), 16 -> 4 (2310), 17 -> 1 (1230)>
>>> item.vertex(1).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 3 (0123), 1 -> 4 (0231)>

The (invisible) root of the packet tree is in the variable [root].
The selected packet (fLLQcbdeeedhrapur) is in the variable [item].
Ready.
>>> item.vertex(0).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (1230), 2 -> 1 (0231), 3 -> 3 (3210), 4 -> 4 (3102), 5 -> 4 (2103), 6 -> 0 (0231), 7 -> 3 (0123), 8 -> 1 (1023), 9 -> 2 (0132), 10 -> 1 (0132), 11 -> 2 (0123), 12 -> 1 (1230), 13 -> 3 (2301), 14 -> 0 (0123), 15 -> 0 (0132), 16 -> 4 (1230), 17 -> 3 (0132)>
>>> item.vertex(1).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 2 (0231), 1 -> 4 (0231)>

