Regina 7.3
Software for low-dimensional topology
Copyright (c) 1999-2023, The Regina development team

The (invisible) root of the packet tree is in the variable [root].
The selected packet (fLLQcbdeeedhrapur) is in the variable [item].
Ready.
>>> item.vertex(0).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (1230), 2 -> 1 (0231), 3 -> 3 (3210), 4 -> 4 (3102), 5 -> 4 (2103), 6 -> 0 (0231), 7 -> 3 (0123), 8 -> 1 (1023), 9 -> 2 (0132), 10 -> 1 (0132), 11 -> 2 (0123), 12 -> 1 (1230), 13 -> 3 (2301), 14 -> 0 (0123), 15 -> 0 (0132), 16 -> 4 (1230), 17 -> 3 (0132)>
>>> item.vertex(1).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 2 (0231), 1 -> 4 (0231)>

