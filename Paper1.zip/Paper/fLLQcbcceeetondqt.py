Regina 7.3
Software for low-dimensional topology
Copyright (c) 1999-2023, The Regina development team

The (invisible) root of the packet tree is in the variable [root].
The selected packet (fLLQcbcceeetondqt) is in the variable [item].
Ready.
>>> item.vertex(0).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (1320), 2 -> 1 (0123), 3 -> 3 (1230), 4 -> 2 (0231), 5 -> 1 (3012), 6 -> 0 (0123), 7 -> 4 (2013), 8 -> 4 (3012), 9 -> 2 (2103), 10 -> 1 (0231), 11 -> 0 (0132), 12 -> 3 (0132), 13 -> 3 (0231), 14 -> 2 (0132), 15 -> 0 (0231), 16 -> 4 (2310), 17 -> 1 (1230)>
>>> item.vertex(1).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 3 (0123), 1 -> 4 (0231)>

