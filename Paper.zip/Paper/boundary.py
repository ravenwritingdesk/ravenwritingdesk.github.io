Regina 7.3
Software for low-dimensional topology
Copyright (c) 1999-2023, The Regina development team

The (invisible) root of the packet tree is in the variable [root].
The selected packet (Whitehead link (Complement)) is in the variable [item].
Ready.
>>> item
<regina.PacketOfSnapPeaTriangulation: Ideal orientable 3-D triangulation, f = ( 2 5 10 5 ), cusps: [ vertex 0, vertex 1 ]>
>>> item.vertex(0).buildLink
<bound method PyCapsule.buildLink of <regina.Face3_0: Vertex 0, torus cusp, degree 18: 0 (0), 2 (0), 1 (0), 4 (2), 2 (3), 4 (0), 3 (0), 3 (1), 2 (2), 3 (3), 0 (2), 2 (1), 0 (1), 1 (1), 4 (1), 1 (2), 0 (3), 4 (3)>>
>>> item.vertex(1).buildLink()
<regina.Triangulation2: Closed orientable 2-D triangulation, f = ( 1 3 2 )>
>>> item.vertex(0).buildLink()
<regina.Triangulation2: Closed orientable 2-D triangulation, f = ( 9 27 18 )>
>>> item.vertex(0).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (3210), 2 -> 1 (1230), 3 -> 4 (0312), 4 -> 2 (0123), 5 -> 4 (2310), 6 -> 3 (1320), 7 -> 3 (0321), 8 -> 2 (0132), 9 -> 3 (0123), 10 -> 0 (0132), 11 -> 2 (0321), 12 -> 0 (0231), 13 -> 1 (0231), 14 -> 4 (0321), 15 -> 1 (0132), 16 -> 0 (0123), 17 -> 4 (0123)>
>>> item.vertex(1).buildLinkInclusion()
<regina.Isomorphism3: 0 -> 1 (0123), 1 -> 3 (0132)>
>>> item.vertex(0).buildLinkInclusion().facePerm()
Traceback (most recent call last):
  File "<console>", line 1, in <module>
TypeError: facePerm(): incompatible function arguments. The following argument types are supported:
    1. (self: regina.Isomorphism3, arg0: int) -> regina.Perm4

Invoked with: <regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (3210), 2 -> 1 (1230), 3 -> 4 (0312), 4 -> 2 (0123), 5 -> 4 (2310), 6 -> 3 (1320), 7 -> 3 (0321), 8 -> 2 (0132), 9 -> 3 (0123), 10 -> 0 (0132), 11 -> 2 (0321), 12 -> 0 (0231), 13 -> 1 (0231), 14 -> 4 (0321), 15 -> 1 (0132), 16 -> 0 (0123), 17 -> 4 (0123)>
>>> item.vertex(0).buildLinkInclusion().facePerm
<bound method PyCapsule.facePerm of <regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (3210), 2 -> 1 (1230), 3 -> 4 (0312), 4 -> 2 (0123), 5 -> 4 (2310), 6 -> 3 (1320), 7 -> 3 (0321), 8 -> 2 (0132), 9 -> 3 (0123), 10 -> 0 (0132), 11 -> 2 (0321), 12 -> 0 (0231), 13 -> 1 (0231), 14 -> 4 (0321), 15 -> 1 (0132), 16 -> 0 (0123), 17 -> 4 (0123)>>
>>> item.vertex(1).buildLinkInclusion().facePerm
<bound method PyCapsule.facePerm of <regina.Isomorphism3: 0 -> 1 (0123), 1 -> 3 (0132)>>
>>> item.vertex(1).buildLinkInclusion().tetImage
<bound method PyCapsule.tetImage of <regina.Isomorphism3: 0 -> 1 (0123), 1 -> 3 (0132)>>
>>> item.vertex(0).buildLinkInclusion().tetImage
<bound method PyCapsule.tetImage of <regina.Isomorphism3: 0 -> 0 (1230), 1 -> 2 (3210), 2 -> 1 (1230), 3 -> 4 (0312), 4 -> 2 (0123), 5 -> 4 (2310), 6 -> 3 (1320), 7 -> 3 (0321), 8 -> 2 (0132), 9 -> 3 (0123), 10 -> 0 (0132), 11 -> 2 (0321), 12 -> 0 (0231), 13 -> 1 (0231), 14 -> 4 (0321), 15 -> 1 (0132), 16 -> 0 (0123), 17 -> 4 (0123)>>

